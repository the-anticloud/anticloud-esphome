# 25 Millennium Problem Proposals

**Project:** ESPHOME
**Upstream:** https://github.com/esphome/esphome

Content specific to ESPHOME in category CONSUMER_APPLIANCES.
