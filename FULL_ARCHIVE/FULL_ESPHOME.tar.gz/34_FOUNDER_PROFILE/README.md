# 34 Founder Profile

**Project:** ESPHOME
**Upstream:** https://github.com/esphome/esphome

Content specific to ESPHOME in category CONSUMER_APPLIANCES.
