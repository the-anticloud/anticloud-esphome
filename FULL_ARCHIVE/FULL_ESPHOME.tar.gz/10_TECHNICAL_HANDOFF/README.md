# 10 Technical Handoff

**Project:** ESPHOME
**Upstream:** https://github.com/esphome/esphome

Content specific to ESPHOME in category CONSUMER_APPLIANCES.
